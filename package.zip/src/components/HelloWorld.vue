<template>
  <div class="jumbotron custom-bg-dark">
    <h1 class="display-4">Yoni-Witz-Landis</h1>
    <p class="lead">
      This is a sample Landis application, built with MongoDB, ExpressJS, VueJS,
      and Node technologies
    </p>
    <hr class="my-4" />
    <p>Click below to see all home applicants</p>
    <router-link class="btn btn-success btn-lg" to="/applicants" exact>View Applicants</router-link>
  </div>
</template>
